# Vercel OpenAI API Proxy
Use this to forward chat messages to OpenAI's ChatGPT API securely.